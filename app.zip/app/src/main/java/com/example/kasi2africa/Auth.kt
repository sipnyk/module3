package com.example.kasi2africa

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class Auth : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // get reference to button
        val buttonClickListener = findViewById<Button>(R.id.button)
        // set on-click listener
        buttonClickListener.setOnClickListener {
            // your code to perform when the user clicks on the button
            val i = Intent(applicationContext, MainActivity::class.java)
            startActivity(i)
        }
    }
}